from .graph import GraphStructure
from .CompleteGraph import CompleteGraph
from .CoralGraph import CoralGraph
from .SimplifiedCoralGraph import SimplifiedCoralGraph
from .ToyGraph import ToyGraph
